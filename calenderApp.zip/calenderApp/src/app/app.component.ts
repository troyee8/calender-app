import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'calenderApp';
  noOfDays:any=[];
  noOfEvent:any=[];
  eventElement:any={};
  show: boolean = false;



   ngOnInit(){

    for(let i=0; i<=20; i++) {
        let day = i+1;
         this.noOfDays.push({day:day, event:false});
    }

    for(let j=1; j<=7; j++) {
      let event = "event"+j;
       this.noOfEvent.push(event);
    }

    this.eventElement.event11 = true;
    
    this.noOfDays[10] = {
      day: 11,
      event:true
    };
    console.log(this.noOfDays);
   }

   addEvent(event){
     console.log(event);
    this.show = !this.show;
   }
}
